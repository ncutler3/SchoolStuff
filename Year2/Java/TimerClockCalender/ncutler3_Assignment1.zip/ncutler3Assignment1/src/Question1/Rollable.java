package Question1;

public interface Rollable {
    public void rollUp();
    public void rollDown();
}
