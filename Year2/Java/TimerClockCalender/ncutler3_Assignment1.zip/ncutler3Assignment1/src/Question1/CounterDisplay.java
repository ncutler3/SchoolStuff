package Question1;

public interface CounterDisplay {
    public void reset();
    public void shuffle();
    public void increase();
    public void decrease();
}
